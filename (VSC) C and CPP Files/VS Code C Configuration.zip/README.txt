Drop this into the main directory of your folder files like this

Main Folder (Drop it here)
 |______________
               |
        ProblemSomething (Code)

To Build, click Terminal and click Run Task and select which build to do.
To Run, click Run and select Run Without Debugging.